import { Component, OnInit } from '@angular/core';
import { ElementSchemaRegistry } from '@angular/compiler';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:string;
  password:string;
  message:string;
  constructor() { }

  ngOnInit() {
  }

  validate()
  {
    if(this.username == "swap" && this.password=="123")
    {
      this.message="success";
    }
    else{
      this.message="invalidate";
    }
  }

}
