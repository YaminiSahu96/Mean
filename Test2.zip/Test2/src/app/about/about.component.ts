import { Component, OnInit } from '@angular/core';
import * as data1 from '../data1.json';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  datarec:any=(data1 as any).default;

  constructor() { 
    
  

  }

  ngOnInit() {
  }

}
