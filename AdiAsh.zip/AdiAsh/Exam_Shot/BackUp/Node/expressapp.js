express = require("express");
bodyparser = require("body-parser");
emis = require("./emi");

app = express();

var logger=function(req,resp,next){
			console.log(req.url);
			next();
}

app.use(bodyparser.urlencoded({extended:false}));
app.use(logger);

app.get("/",function(req,resp){
		resp.sendFile("index.html",{root:__dirname});
});

app.post("/process",function(req,resp){
		emi = emis.calculate(req.body.amount,req.body.duration);
		console.log(emi);
        var str = "";
        str = "Emi is " + emi;
		resp.send(str);
});

app.listen(2000);
console.log("server running on port 2000");