exports.calculate = function(a,b){
    
    amount = a;
    duration = b;

    return (a*0.08)*duration;
}