import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';
import { customer } from '../customer/customer';
import 'rxjs/add/operator/map';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  
  baseurl = "assets/Customer.json";
  
  constructor(private http : Http) { }

  getAllCustomers():Observable<customer[]>{
    return  this.http.get(this.baseurl).map(r=>r.json());
  }

}
