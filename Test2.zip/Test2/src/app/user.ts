export class User {
    
}
